---
name: auto-video-dubbing
description: Xử lý video tiếng Anh thành tiếng Việt. Bao gồm trích xuất audio, dùng Gemini phân tích SRT, tạo TTS tiếng Việt (edge-tts) và ghép phụ đề, lồng tiếng tự động vào video (ffmpeg).
---

# Skill: Auto Video Dubbing (Tự Động Lồng Tiếng & Vietsub)

## Trường hợp sử dụng
Gọi skill này khi người dùng yêu cầu:
- "Lồng tiếng video này sang tiếng Việt"
- "Thêm phụ đề tiếng Việt và đọc tiếng Việt cho video tiếng Anh"
- "Chạy auto dubber cho video X"

## Quy trình thực hiện (Workflow)

1. **Kiểm tra môi trường:**
   - Đảm bảo trong thư mục dự án có file `auto_dubber.py`.
   - Đảm bảo có thư mục `sanpham` chứa file video gốc (thường là `sanpham.mp4`).
   - Đảm bảo có file `.env` chứa `GEMINI_API_KEY`.

2. **Cài đặt thư viện (Nếu chưa có):**
   - Chạy lệnh cài đặt các thư viện cần thiết: `pip install google-genai pydub audioop-lts edge-tts python-dotenv`
   - Đảm bảo hệ thống đã cài FFmpeg.

3. **Chạy Script lồng tiếng:**
   - Thực thi lệnh: `python auto_dubber.py`
   - Chờ tiến trình chạy xong. Do gọi API TTS liên tục nên script này có thể chạy từ 3 - 5 phút tùy thời lượng video.

4. **Kiểm tra Output:**
   - Xác nhận file kết quả `sanpham/sanpham_vi_dub.mp4` đã được tạo ra thành công.
   - Các file tạm sinh ra: `original_audio.mp3`, `subtitles.srt`, `dubbed_vi.mp3` và hàng loạt file `temp_x.mp3`.

## Cấu trúc của `auto_dubber.py` (Tham khảo nhanh)
Script sử dụng các thành phần sau:
- **`ffmpeg`** để trích xuất `audio.mp3` từ video gốc.
- **`google-genai` (Gemini 3.5 Flash)** nhận audio file, dịch sang tiếng Việt và trả về định dạng `SRT` kèm timestamp.
- Hàm phân tích SRT bằng Regex để lấy thời gian bắt đầu và kết thúc của từng câu.
- **`edge-tts` (vi-VN-NamMinhNeural)** để chuyển các câu SRT thành audio `.mp3` ngắn. Bắt lỗi `NoAudioReceived` nếu text trống.
- **`pydub`** đặt từng đoạn `.mp3` vào một master track tĩnh lặng, khớp chính xác với `start_ms` từ SRT.
- Cuối cùng, **`ffmpeg`** trộn Video + Audio Dub + Burn-in SRT thành file MP4 hoàn chỉnh.

## Cách AI tương tác với người dùng
- Khi người dùng kích hoạt skill này, AI không cần giải thích dài dòng, hãy ngay lập tức kiểm tra video gốc và chạy tiến trình.
- Cập nhật tiến độ sau khi kích hoạt lệnh chạy ngầm và hẹn người dùng vài phút để xem kết quả.
